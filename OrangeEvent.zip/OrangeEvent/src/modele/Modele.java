package modele;


import controleur.Client;
import controleur.Intervention;
import controleur.Produit;
import controleur.Technicien;
import controleur.User;
import vue.PanelProduit;

import java.sql.*;
import java.util.ArrayList;

public class Modele {
	//instanciation e la connexion MYSQL
	private static BDD uneBdd = new BDD ("localhost", "orange_efrei", "root", "");
	public static User verifConnexion (String email, String mdp) {
		User unUser=null;
		String requete= "Select * from user where email= ? and mdp= ? ;";
		try {
			uneBdd.seConnecter();
			PreparedStatement unStat = uneBdd.getMaConnextion().prepareStatement(requete) ;
			//affecter des données aux parametres 
			unStat.setString(1, email);
			unStat.setString(2, mdp);
			ResultSet unRes =  unStat.executeQuery(); 
			if(unRes.next()) {
				unUser= new User (
						unRes.getInt("iduser"), unRes.getString("nom"), unRes.getString("prenom"), unRes.getString("email"),
						unRes.getString("mdp"), unRes.getString("Role")
						);
			}
			unStat.close();
			uneBdd.chargerDeconnecter();
		} catch (SQLException exp) {
			System.out.println("Erreur de connexion:"+requete );
			exp.printStackTrace();
		}
		return unUser;
	}
	public static void updateUser(User unUser) {
		String requete = "update user set nom='"+unUser.getNom()+"', prenom='"+unUser.getPrenom()+"', email='"+unUser.getEmail()+"', mdp='"+unUser.getMdp()+"', role='"+unUser.getRole()+"' where iduser="+unUser.getIduser();
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	//Gestion des clients
	public static void insertClient(Client unClient) {
		String requete="insert into client values (null, '"+unClient.getNom()+"', '"+unClient.getPrenom()+"', '"+unClient.getAdresse()+"','"+unClient.getEmail()+"');";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static ArrayList<Client> selectAllClients (String filtre){
		ArrayList<Client> lesClients = new ArrayList<Client>(); 
		String requete ; 
		System.out.println("filtre ; " + filtre);
		if (filtre.equals("")) {
			requete="select * from client ; ";
		}else {
			requete="select * from client where nom like '%"+filtre+"%' or "
					+" prenom like '%"+filtre+"%' or adresse like '%"+filtre+"%' or email like '%"+filtre+"%';";
		}
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnextion().createStatement(); 
			ResultSet desRes = unStat.executeQuery(requete); 
			while (desRes.next()) {
				Client unClient = new Client (
						desRes.getInt("idclient"), desRes.getString("nom"), 
						desRes.getString("prenom"),desRes.getString("adresse"),
						desRes.getString("email")
						);
				lesClients.add(unClient);
			}
			unStat.close();
			uneBdd.chargerDeconnecter();
		 }
		 catch(SQLException exp) {
				System.out.println("Erreur execution requete :" + requete);
				exp.printStackTrace();
			}
		return lesClients ;
	}
	public static void deleteClient (int idClient) {
		String requete="delete from client where idclient="+idClient+";";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static void updateClient (Client unClient) {
		String requete="update client set nom='"+unClient.getNom()+"', prenom='"+unClient.getPrenom()+"', adresse='"+unClient.getAdresse()+"', email='"+unClient.getEmail()+"' where idclient="+unClient.getIdclient();
		System.out.println(requete);
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static Client selectCompteClient(User unUser) {
		int compte = unUser.getIduser();
	    String requete = "SELECT * FROM client INNER JOIN user ON user.iduser=client.compte WHERE user.iduser="+compte+";";
	    Client unClient2 = null;
	    
	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnextion().createStatement();
	        ResultSet desRes = unStat.executeQuery(requete);

	        if (desRes.next()) {
	            unClient2 = new Client(
	                desRes.getInt("idclient"),
	                desRes.getString("nom"),
	                desRes.getString("prenom"),
	                desRes.getString("adresse"),
	                desRes.getString("email")
	            );
	        }

	        unStat.close();
	        uneBdd.chargerDeconnecter();
	    } catch (SQLException exp) {
	        System.out.println("Erreur execution requete: " + requete);
	        exp.printStackTrace();
	    }

	    return unClient2;
	}
	//Gestion des produits
	public static void insertProduit(Produit unProduit) {
		String requete="insert into produit values (null, '"+unProduit.getDesignation()+"', '"+unProduit.getPrxiAchat()+"', '"+unProduit.getDateAchat()+"','"+unProduit.getCategorie()+"','"+unProduit.getIdclient()+"');";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static ArrayList<Produit> seletAllProduit(String filtre){
		ArrayList<Produit> lesProduits = new ArrayList<Produit>();
		String requete;
		if (filtre.equals("")) {
			requete="select * from produit;";
		} else {
		    requete = "SELECT * FROM produit WHERE designation LIKE '%" + filtre + "%' OR prixAchat LIKE '%" + filtre + "%' OR dateAchat LIKE '%" + filtre + "%' OR categorie LIKE '%" + filtre + "%' OR idclient LIKE '%" + filtre + "%';";
		}
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			ResultSet desRes= unStat.executeQuery(requete);
			while (desRes.next()) {
				Produit unProduit = new Produit (desRes.getInt("idproduit"), desRes.getString("designation"), desRes.getFloat("prixAchat"), desRes.getString("dateAchat"), desRes.getString("categorie"), desRes.getInt("idclient"));
				lesProduits.add(unProduit);
			}
			unStat.close();
			uneBdd.chargerDeconnecter();
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
		return lesProduits;
	}
	public static void deleteProduit (int idClient) {
		String requete="delete from produit where idproduit="+idClient+";";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static void updateProduit (Produit unProduit) {
		String requete="update produit set designation='"+unProduit.getDesignation()+"', prixAchat='"+unProduit.getPrxiAchat()+"', dateAchat='"+unProduit.getDateAchat()+"', categorie='"+unProduit.getCategorie()+"', idclient='"+unProduit.getIdclient()+ "' where idproduit="+unProduit.getIdproduit();
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static Produit selectProduitsClient(User unUser) {
		int compte = unUser.getIduser();
	    String requete = "SELECT * FROM produit NATURAL JOIN client INNER JOIN user ON user.iduser=client.compte WHERE user.iduser='"+compte+"';";
	    Produit unProduit2 = null;
	    
	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnextion().createStatement();
	        ResultSet desRes = unStat.executeQuery(requete);

	        if (desRes.next()) {
	            unProduit2 = new Produit(
	                desRes.getInt("idproduit"),
	                desRes.getString("designation"),
	                desRes.getFloat("prixAchat"),
	                desRes.getString("dateAchat"),
	                desRes.getString("categorie"),
	                desRes.getInt("idclient")
	            );
	        }
	        unStat.close();
	        uneBdd.chargerDeconnecter();
	    } catch (SQLException exp) {
	        System.out.println("Erreur execution requete: " + requete);
	        exp.printStackTrace();
	    }

	    return unProduit2;
	}
	//Gestion des techniciens
	public static void insertTechnicien(Technicien unTechnicien) {
		String requete="insert into technicien values (null, '"+unTechnicien.getNom()+"', '"+unTechnicien.getPrenom()+"', '"+unTechnicien.getSpecialite()+"','"+unTechnicien.getDateEmbauche()+"', null);";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static ArrayList<Technicien> selectAllTechnicien(String filtre) {
		// TODO Auto-generated method stub
		ArrayList<Technicien> lesTechniciens = new ArrayList<Technicien>();
		String requete;
		if (filtre.isEmpty()) {
			requete="select * from technicien;";
		} else {
		    requete = "SELECT * FROM technicien WHERE nom LIKE '%" + filtre + "%' OR prenom LIKE '%" + filtre + "%' OR specialite LIKE '%" + filtre + "%' OR dateEmbauche LIKE '%" + filtre + "%';";
		}
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			ResultSet desRes= unStat.executeQuery(requete);
			while (desRes.next()) {
				Technicien unTechnicien = new Technicien (desRes.getInt("idtechnicien"), desRes.getString("nom"), desRes.getString("prenom"), desRes.getString("specialite"), desRes.getString("dateEmbauche"));
				lesTechniciens.add(unTechnicien);
			}
			unStat.close();
			uneBdd.chargerDeconnecter();
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
		return lesTechniciens;
	}
	public static void deleteTechnicien (int idTechnicien) {
		String requete="delete from technicien where idtechnicien="+idTechnicien+";";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static void updateTechnicien (Technicien unTechnicien) {
		String requete="update technicien set nom='"+unTechnicien.getNom()+"', prenom='"+unTechnicien.getPrenom()+"', specialite='"+unTechnicien.getSpecialite()+"', dateEmbauche='"+unTechnicien.getDateEmbauche()+"' where idtechnicien="+unTechnicien.getIdtechnicien();
		System.out.println(requete);
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	} public static Technicien selectCompteTechnicien(User unUser) {
		int compte = unUser.getIduser();
	    String requete = "SELECT * FROM technicien INNER JOIN user ON user.iduser=technicien.compte WHERE user.iduser="+compte+";";
	    System.out.println(requete);
	    Technicien unTechnicien2 = null;
	    
	    try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnextion().createStatement();
	        ResultSet desRes = unStat.executeQuery(requete);

	        if (desRes.next()) {
	            unTechnicien2 = new Technicien(
	                desRes.getInt("idtechnicien"),
	                desRes.getString("nom"),
	                desRes.getString("prenom"),
	                desRes.getString("specialite"),
	                desRes.getString("dateEmbauche")
	            );
	        }

	        unStat.close();
	        uneBdd.chargerDeconnecter();
	    } catch (SQLException exp) {
	        System.out.println("Erreur execution requete: " + requete);
	        exp.printStackTrace();
	    }

	    return unTechnicien2;
	}
	//Gestion des interventions
	public static void insertIntervention(Intervention unIntervention) {
		String requete="insert into intervention values (null, '"+unIntervention.getDescrip()+"', '"+unIntervention.getPrixInter()+"', '"+unIntervention.getDateInter()+"','"+unIntervention.getIdProduit()+"','"+unIntervention.getIdTechnicien()+"');";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static ArrayList<Intervention> selectAllIntervention(String filtre) {
		// TODO Auto-generated method stub
		ArrayList<Intervention> lesInterventions = new ArrayList<Intervention>();
		String requete;
		if (filtre.equals("")) {
			requete="select * from intervention;";
		} else {
		    requete = "SELECT * FROM intervention WHERE description LIKE '%" + filtre + "%' OR prixInter LIKE '%" + filtre + "%' OR dateInter LIKE '%" + filtre + "%' OR idproduit LIKE '%" + filtre + "%' OR idtechnicien LIKE '%" + filtre + "%';";
		}
		System.out.println(requete);
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			ResultSet desRes= unStat.executeQuery(requete);
			while (desRes.next()) {
				Intervention unIntervention = new Intervention (desRes.getInt("idinter"), desRes.getString("description"), desRes.getFloat("prixInter"), desRes.getString("dateInter"), desRes.getInt("idproduit"), desRes.getInt("idtechnicien"));
				lesInterventions.add(unIntervention);
			}
			unStat.close();
			uneBdd.chargerDeconnecter();
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
		return lesInterventions;
	}
	public static void deleteIntervention (int idIntervention) {
		String requete="delete from intervention where idinter="+idIntervention+";";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static void updateInter (Intervention uneIntervention) {
		String requete="update intervention set description='"+uneIntervention.getDescrip()+"', prixInter='"+uneIntervention.getPrixInter()+"', dateInter='"+uneIntervention.getDateInter()+"', idproduit='"+uneIntervention.getIdProduit()+"', idtechnicien= '"+uneIntervention.getIdTechnicien()+"' where idinter='"+uneIntervention.getIdInter()+"';";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static void appelProcedure (String nomP, String tab[]) {
		String chaine="'"+String.join("','", tab)+"'";
		String requete="call "+ nomP +"("+ chaine +") ; ";
		try {
			uneBdd.seConnecter();
			Statement unStat= uneBdd.getMaConnextion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.chargerDeconnecter();
		} catch(SQLException exp) {
			System.out.println("Erreur execution requete: "+ requete);
			exp.printStackTrace();
		}
	}
	public static Intervention selectMesInters(User unUser) {
		// TODO Auto-generated method stub
		String requete;
		Intervention uneIntervention = null;
		int compte= unUser.getIduser();
		requete="select * from intervention WHERE idtechnicien IN (SELECT idtechnicien FROM technicien WHERE compte='"+compte+"');";
		try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnextion().createStatement();
	        ResultSet desRes = unStat.executeQuery(requete);

		if (desRes.next()) {
            uneIntervention = new Intervention(
            desRes.getInt("idinter"), desRes.getString("description"), desRes.getFloat("prixInter"), desRes.getString("dateInter"), desRes.getInt("idproduit"), desRes.getInt("idtechnicien"));	
        }

        unStat.close();
        uneBdd.chargerDeconnecter();
    } catch (SQLException exp) {
        System.out.println("Erreur execution requete: " + requete);
        exp.printStackTrace();
    }
		return uneIntervention;
	}
	public static Intervention selectMesIntervention(User unUser) {
		// TODO Auto-generated method stub
		String requete;
		Intervention uneIntervention = null;
		int compte= unUser.getIduser();
		requete="select * from intervention NATURAL JOIN produit NATURAL JOIN client WHERE client.compte='"+compte+"';";
		try {
	        uneBdd.seConnecter();
	        Statement unStat = uneBdd.getMaConnextion().createStatement();
	        ResultSet desRes = unStat.executeQuery(requete);

		if (desRes.next()) {
            uneIntervention = new Intervention(
            desRes.getInt("idinter"), desRes.getString("description"), desRes.getFloat("prixInter"), desRes.getString("dateInter"), desRes.getInt("idproduit"), desRes.getInt("idtechnicien"));	
        }

        unStat.close();
        uneBdd.chargerDeconnecter();
    } catch (SQLException exp) {
        System.out.println("Erreur execution requete: " + requete);
        exp.printStackTrace();
    }
		return uneIntervention;
	}
}

