package controleur;

import java.util.*;

import modele.Modele;

public class Controleur {
	public static User verifConnexion (String email, String mdp) {
		return Modele.verifConnexion(email, mdp);
	}

	public static void updateUser(User unUser) {
		Modele.updateUser(unUser);
	}
	
	//Gestion Client
	public static void insertClient(Client unClient) {
		Modele.insertClient(unClient);
	}
	public static ArrayList<Client> selectAllClients(String filtre){
		return Modele.selectAllClients(filtre);
	}
	public static void deleteClient(int idClient) {
		Modele.deleteClient(idClient);
	}
	public static void pdateClient(Client unClient) {
		Modele.updateClient(unClient);
	}
	public static Client selectCompteClient(){
		return Modele.selectCompteClient(unUser);
	}
	//Gestion Produit
	public static void insertProduit(Produit unProduit) {
		Modele.insertProduit(unProduit);
	}
	public static ArrayList<Produit> selectAllProduits(String filtre){
		System.out.println(filtre);
		return Modele.seletAllProduit(filtre);
	}
	public static void deleteProduit(int idClient) {
		Modele.deleteProduit(idClient);
	}
	public static void updateProduit(Produit unProduit) {
		Modele.updateProduit(unProduit);
	}
	public static Produit selectProduitsClient(User unUser){
		return Modele.selectProduitsClient(unUser);
	}
	//Gestion Technicien
	public static void insertTechnicien(Technicien unTechnicien) {
		Modele.insertTechnicien(unTechnicien);
	}
	public static ArrayList<Technicien> selectAllTechnicien(String filtre){
		return Modele.selectAllTechnicien(filtre);
	}
	public static void deleteTechnicien(int idTechnicien) {
		Modele.deleteTechnicien(idTechnicien);
	}
	public static void updateTechnicien(Technicien unTechnicien) {
		Modele.updateTechnicien(unTechnicien);
	}
	public static Technicien selectCompteTechnicien(User unUser){
		return Modele.selectCompteTechnicien(unUser);
	}
	//Gestion Intervention
	public static void insertIntervention(Intervention unIntervention) {
		Modele.insertIntervention(unIntervention);
	}
	public static ArrayList<Intervention> selectAllIntervention(String filtre){
		return Modele.selectAllIntervention(filtre);
	}
	public static void deleteIntervention(int idIntervention) {
		Modele.deleteIntervention(idIntervention);
	}
	public static void updateInter(Intervention unInter) {
		Modele.updateInter(unInter);
	}
	public static void appelProcedure (String nomP, String tab[]) {
		Modele.appelProcedure(nomP, tab);
	}
	public static Intervention selectMesInters(User unUser){
		return Modele.selectMesInters(unUser);
	}
	public static Intervention selectMesIntervention(User unUser){
		return Modele.selectMesIntervention(unUser);
	}
}
