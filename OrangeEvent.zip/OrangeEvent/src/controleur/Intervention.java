package controleur;

public class Intervention {
	private int IdInter;
	private String descrip;
	private float prixInter;
	private String dateInter;
	private int idProduit;
	private int idTechnicien;
	public Intervention(int idInter, String descrip, float prixInter, String dateInter, int idProduit,
			int idTechnicien) {
		super();
		IdInter = idInter;
		this.descrip = descrip;
		this.prixInter = prixInter;
		this.dateInter = dateInter;
		this.idProduit = idProduit;
		this.idTechnicien = idTechnicien;
	}
	public Intervention(String descrip, float prixInter, String dateInter, int idProduit,
			int idTechnicien) {
		super();
		IdInter = 0;
		this.descrip = descrip;
		this.prixInter = prixInter;
		this.dateInter = dateInter;
		this.idProduit = idProduit;
		this.idTechnicien = idTechnicien;
	}
	public int getIdInter() {
		return IdInter;
	}
	public void setIdInter(int idInter) {
		IdInter = idInter;
	}
	public String getDescrip() {
		return descrip;
	}
	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}
	public float getPrixInter() {
		return prixInter;
	}
	public void setPrixInter(float prixInter) {
		this.prixInter = prixInter;
	}
	public String getDateInter() {
		return dateInter;
	}
	public void setDateInter(String dateInter) {
		this.dateInter = dateInter;
	}
	public int getIdProduit() {
		return idProduit;
	}
	public void setIdProduit(int idProduit) {
		this.idProduit = idProduit;
	}
	public int getIdTechnicien() {
		return idTechnicien;
	}
	public void setIdTechnicien(int idTechnicien) {
		this.idTechnicien = idTechnicien;
	}
	
}
