package controleur;

import javax.swing.table.AbstractTableModel;

public class Tableau extends AbstractTableModel{

	private Object donnees [][];
	private String entetes [];
	
	public Tableau(Object[][] donnees, String[] entetes) {
		super();
		this.donnees = donnees;
		this.entetes = entetes;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return donnees.length;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return entetes.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return donnees[rowIndex][columnIndex];
	}

	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return entetes[column];
	}
	public void setDonnees(Object matrice[][]) {
		this.donnees=matrice;
		//Actualise le tableau
		this.fireTableDataChanged();
	}
}
