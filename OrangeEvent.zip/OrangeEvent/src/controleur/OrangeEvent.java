package controleur;
import modele.*;
import vue.*;


public class OrangeEvent {
	private static VueConnection uneVueConnection;
	private static VueGenerale uneVueGenerale;
	public static void main(String args[]) {
		uneVueConnection = new VueConnection();
		
	}
	public static void rendreVisibleLaVueGenerale (boolean action, User unUser) {
		if (action == true) {
			uneVueGenerale = new VueGenerale(unUser);
			uneVueGenerale.setVisible(true);
		} else {
			uneVueGenerale.dispose();
		}
	}
	public static void rendreVisibleVueConnection (boolean action) {
		uneVueConnection.setVisible(action);
	}
}
