package controleur;

public class Produit {
	private int idproduit;
	private String designation;
	private float prxiAchat;
	private String dateAchat, categorie;
	private int idclient;
	public Produit(int idproduit, String designation, float prxiAchat, String dateAchat, String categorie, int idclient) {
		super();
		this.idproduit = idproduit;
		this.designation = designation;
		this.prxiAchat = prxiAchat;
		this.dateAchat = dateAchat;
		this.categorie = categorie;
		this.idclient = idclient;
	}
	public Produit( String designation, float prxiAchat, String dateAchat, String categorie, int idclient) {
		super();
		this.idproduit = 0;
		this.designation = designation;
		this.prxiAchat = prxiAchat;
		this.dateAchat = dateAchat;
		this.categorie = categorie;
		this.idclient = idclient;
	}
	public int getIdproduit() {
		return idproduit;
	}
	public void setIdproduit(int idproduit) {
		this.idproduit = idproduit;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public float getPrxiAchat() {
		return prxiAchat;
	}
	public void setPrxiAchat(float prxiAchat) {
		this.prxiAchat = prxiAchat;
	}
	public String getDateAchat() {
		return dateAchat;
	}
	public void setDateAchat(String dateAchat) {
		this.dateAchat = dateAchat;
	}
	public String getCategorie() {
		return categorie;
	}
	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}
	public int getIdclient() {
		return idclient;
	}
	public void setIdclient(int idclient) {
		this.idclient = idclient;
	}
	
}
