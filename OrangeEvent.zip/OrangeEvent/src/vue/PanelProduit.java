package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import controleur.Client;
import controleur.Controleur;
import controleur.Produit;
import controleur.Tableau;
import controleur.User;

public class PanelProduit extends PanelPrincipal implements ActionListener {
	private JPanel panelForm= new JPanel();
	private JTextField txtDesignation = new JTextField();
	private JTextField txtPrixAchat = new JTextField();
	private JTextField txtDateAchat = new JTextField();
	private JComboBox<String> txtCategorie = new JComboBox<String>();
	private static JComboBox<String> txtIdClient = new JComboBox<String>();
	private JButton btEnregistrer = new JButton("Enregistrer");
	private JButton btAnnuler = new JButton("Annuler");
	private JTable tableProduits;
	private JScrollPane uneScroll;
	private Tableau unTableau;
	private JPanel panelFiltre = new JPanel();
	private JButton btFiltrer = new JButton("Filtrer");
	private JTextField txtFiltre = new JTextField();
	private JLabel txtNbProduit= new JLabel();
	public String role;
	private Client currentClient;
	private User unUser;
	public PanelProduit (User unUser) {
		super ("Gestion des Produits");
		this.role = unUser.getRole();
		this.unUser = unUser; 
		currentClient = Controleur.selectCompteClient(unUser);
		this.txtCategorie.addItem("Téléphone");
		this.txtCategorie.addItem("Informatique");
		this.txtCategorie.addItem("Télévision");
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setBounds(40, 100, 350, 300);
		this.panelForm.setLayout(new GridLayout(6, 2));
		if (!this.role.equals("user")) {
			this.panelForm.add(new JLabel("Désignation produit:"));
			this.panelForm.add(this.txtDesignation);
			this.panelForm.add(new JLabel("Prix d'achat produit:"));
			this.panelForm.add(this.txtPrixAchat);
			this.panelForm.add(new JLabel("Date d'achat produit:"));
			this.panelForm.add(this.txtDateAchat);
			this.panelForm.add(new JLabel("Catégorie produit:"));
			this.panelForm.add(this.txtCategorie);
			if (!this.role.equals("client")) {
				this.panelForm.add(new JLabel("Client concerné:"));
				this.panelForm.add(this.txtIdClient);
			}
			this.panelForm.add(this.btEnregistrer);
			if (this.role.equals("client")) {
				btEnregistrer.setText("Modifier");
			}
			this.panelForm.add(this.btAnnuler);
			this.add(this.panelForm);
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(420, 110, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Produit", "Désignation", "Prix d'achat", "Date d'achat", "Catégorie", "Client concerné"};
			this.unTableau = new Tableau(this.obtenirDonnees("", unUser), entetes);
			this.tableProduits = new JTable (this.unTableau);
			this.uneScroll= new JScrollPane(this.tableProduits);
			this.uneScroll.setBounds(420, 160, 350, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbProduit.setBounds(440, 440, 300, 20);
			this.txtNbProduit.setText("Le nombre de produit(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbProduit);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
			this.remplirCBXClients();
		} else if (this.role.equals("user")){
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(20, 100, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Produit", "Désignation", "Prix d'achat", "Date d'achat", "Catégorie", "Client concerné"};
			this.unTableau = new Tableau(this.obtenirDonnees("", unUser), entetes);
			this.tableProduits = new JTable (this.unTableau);
			this.uneScroll= new JScrollPane(this.tableProduits);
			this.uneScroll.setBounds(20, 160, 650, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbProduit.setBounds(270, 440, 300, 20);
			this.txtNbProduit.setText("Le nombre de produit(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbProduit);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
		}
		if (!this.role.equals("user")) {
	this.tableProduits.addMouseListener(new MouseListener() {
		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			int numLigne, idClient;
			if(e.getClickCount() >=2) {
				numLigne= tableProduits.getSelectedRow();
				idClient=Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
				int response = JOptionPane.showConfirmDialog(null,  "Voulez vous supprimer le produit?", "Suppression produit", JOptionPane.YES_NO_OPTION);
				if (response==0) {
					Controleur.deleteProduit(idClient);
					unTableau.setDonnees(obtenirDonnees("", unUser));
					PanelProduit.remplirCBXClients();
					//Actualisation du nombre de client
					txtNbProduit.setText("Le nombre de produit(s) est: "+unTableau.getRowCount());
				}
			} else if (e.getClickCount() == 1) {
				numLigne = tableProduits.getSelectedRow();
				txtDesignation.setText(unTableau.getValueAt(numLigne, 1).toString());
				txtPrixAchat.setText(unTableau.getValueAt(numLigne, 2).toString());
				txtDateAchat.setText(unTableau.getValueAt(numLigne, 3).toString());
				txtCategorie.setSelectedItem(unTableau.getValueAt(numLigne, 4).toString());
				txtIdClient.setSelectedItem(unTableau.getValueAt(numLigne, 5).toString());
				btEnregistrer.setText("Modifier");
			}
		}
	});
	}}
	public Object [][] obtenirDonnees(String filtre, User unUser){
		if (!this.role.equals("client")) {
			ArrayList <Produit> lesProduits = Controleur.selectAllProduits(filtre);
			Object [][] matrice = new Object [lesProduits.size()][6];
			int i = 0;
			for (Produit unProduit : lesProduits) {
				matrice [i][0]=unProduit.getIdproduit();
				matrice [i][1]=unProduit.getDesignation();
				matrice [i][2]=unProduit.getPrxiAchat();
				matrice [i][3]=unProduit.getDateAchat();
				matrice [i][4]=unProduit.getCategorie();
				matrice [i][5]=unProduit.getIdclient();
				i++;
			}
			return matrice;
		} else {
			Produit unProduit = Controleur.selectProduitsClient(unUser);
			Object [][] matrice = new Object[1][6];
			 if (unProduit != null) {
			        matrice[0][0] = unProduit.getIdproduit();
			        matrice[0][1] = unProduit.getDesignation();
			        matrice[0][2] = unProduit.getPrxiAchat();
			        matrice[0][3] = unProduit.getDateAchat();
			        matrice[0][4] = unProduit.getCategorie();
			        matrice[0][5] = unProduit.getIdclient();
			    }
			return matrice;
		}
	}
	public  static void remplirCBXClients() {
		PanelProduit.txtIdClient.removeAllItems();
		ArrayList<Client>lesClients = Controleur.selectAllClients("");
		for (Client unClient : lesClients) {
			txtIdClient.addItem(unClient.getIdclient()+"-"+unClient.getNom());
			//Le "this" n'est pas accepter pour désigner les items static. Il suffit d'écrire classeGénérale.item ou juste item
		}
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (this.role.equals("admin") || this.role.equals("techni")) {
			if(e.getSource() == this.btAnnuler) {
				this.txtDesignation.setText("");
				this.txtPrixAchat.setText("");
				this.txtDateAchat.setText("");
				//this.txtCategorie.setText("");
				this.btEnregistrer.setText("Enregistrer");
			} else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
				String designation = this.txtDesignation.getText();
				float prixAchat = Float.parseFloat(this.txtPrixAchat.getText());
				String dateAchat = this.txtDateAchat.getText();
				String Categorie = this.txtCategorie.getSelectedItem().toString();
				String chaine = txtIdClient.getSelectedItem().toString();
				String tab2[] = chaine.split("-");
				int idclient = Integer.parseInt(tab2[0]);
				Produit unProduit = new Produit(designation, prixAchat, dateAchat, Categorie, idclient);
				//Controleur.insertProduit(unProduit);
				String nomP= "insertProduit";
				String tab[]= {designation, prixAchat+"", dateAchat, Categorie, idclient+""};
				Controleur.appelProcedure(nomP, tab);
				this.unTableau.setDonnees(this.obtenirDonnees("", null));
				this.txtDesignation.setText("");
				this.txtPrixAchat.setText("");
				this.txtDateAchat.setText("");
				JOptionPane.showMessageDialog(this, "Opération réussie");
				txtNbProduit.setText("Le nombre de produit(s) est: "+unTableau.getRowCount());
			} else if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			} else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String designation = this.txtDesignation.getText();
				float prixAchat= Float.parseFloat(this.txtPrixAchat.getText());
				String dateAchat= this.txtDateAchat.getText();
				String categorie= this.txtCategorie.getSelectedItem().toString();
				String chaine = txtIdClient.getSelectedItem().toString();
				String tab[] = chaine.split("-");
				int idclient = Integer.parseInt(tab[0]);
				int numLigne = this.tableProduits.getSelectedRow();
				int idproduit= Integer.parseInt(this.unTableau.getValueAt(numLigne,  0).toString());
				Produit unProduit= new Produit (idproduit, designation, prixAchat, dateAchat, categorie, idclient);
				Controleur.updateProduit(unProduit);
				this.unTableau.setDonnees(this.obtenirDonnees("", null));
				this.txtDesignation.setText("");
				this.txtPrixAchat.setText("");
				this.txtDateAchat.setText("");
				this.btEnregistrer.setText("Enregistrer");
				JOptionPane.showMessageDialog(this, "Modification du produit réussie");
				PanelProduit.remplirCBXClients();
			}
		} else if (this.role.equals("client")){
			if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			}  else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String designation = this.txtDesignation.getText();
				float prixAchat= Float.parseFloat(this.txtPrixAchat.getText());
				String dateAchat= this.txtDateAchat.getText();
				String categorie= this.txtCategorie.getSelectedItem().toString();
				/*String chaine = txtIdClient.getSelectedItem().toString();
				String tab[] = chaine.split("-");*/
				int idclient=  currentClient.getIdclient();
				int numLigne = this.tableProduits.getSelectedRow();
				int idproduit= Integer.parseInt(this.unTableau.getValueAt(numLigne,  0).toString());
				Produit unProduit= new Produit (idproduit, designation, prixAchat, dateAchat, categorie, idclient);
				Controleur.updateProduit(unProduit);
				this.unTableau.setDonnees(this.obtenirDonnees("", this.unUser));
				this.txtDesignation.setText("");
				this.txtPrixAchat.setText("");
				this.txtDateAchat.setText("");
				this.btEnregistrer.setText("Enregistrer");
				JOptionPane.showMessageDialog(this, "Modification du produit réussie");
				PanelProduit.remplirCBXClients();
			}
		} else {
			if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			}
		}
	}
}
