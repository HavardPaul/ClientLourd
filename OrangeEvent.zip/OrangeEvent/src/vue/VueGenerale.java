package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import controleur.OrangeEvent;
import controleur.Technicien;
import controleur.User;


public class VueGenerale extends JFrame implements ActionListener{
	private JButton btProfil = new JButton ("Profil");
	private JButton btClient = new JButton ("Client");
	private JButton btProduit = new JButton ("Produit");
	private JButton btTechnicien = new JButton ("Technicien");
	private JButton btIntervention = new JButton ("Intervention");
	private JButton btQuitter = new JButton ("Quitter");
	private JPanel panelMenu = new JPanel ();
	//instanciation des panels
	private PanelProfil unPanelProfil;
	private PanelClient unPanelClient;
	private PanelProduit unPanelProduit;
	private PanelTechnicien unPanelTechnicien;
	private PanelIntervention unPanelIntervention;
	public VueGenerale(User unUser) {
		this.unPanelProfil= new PanelProfil(unUser);
		this.unPanelClient= new PanelClient(unUser);
		this.unPanelProduit= new PanelProduit(unUser);
		this.unPanelTechnicien= new PanelTechnicien(unUser);
		this.unPanelIntervention= new PanelIntervention(unUser);
		this.setTitle("Admin BDO Orange Event");
		this.setBounds(100, 100, 900, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setBackground(Color.gray);
		this.setResizable(false);
		this.setLayout(null);
		//constrution du panel
		this.panelMenu.setBounds(20, 10, 800, 30);
		this.panelMenu.setBackground(Color.gray);
		this.panelMenu.setLayout(new GridLayout(1, 6));
		this.panelMenu.add(this.btProfil);
		this.panelMenu.add(this.btClient);
		this.panelMenu.add(this.btProduit);
		this.panelMenu.add(this.btTechnicien);
		this.panelMenu.add(this.btIntervention);
		this.panelMenu.add(this.btQuitter);
		this.add(this.panelMenu);
		//insertion des panels dans la fenêtre
		this.add(this.unPanelProfil);
		this.add(this.unPanelClient);
		this.add(this.unPanelTechnicien);
		this.add(this.unPanelIntervention);
		this.add(this.unPanelProduit);
		this.btProfil.addActionListener(this);
		this.btClient.addActionListener(this);
		this.btProduit.addActionListener(this);
		this.btTechnicien.addActionListener(this);
		this.btIntervention.addActionListener(this);
		this.btQuitter.addActionListener(this);
		this.setVisible(true);
	} 
	public void afficherPanel (int choix) {
		this.unPanelProfil.setVisible(false);
		this.unPanelClient.setVisible(false);
		this.unPanelProduit.setVisible(false);
		this.unPanelTechnicien.setVisible(false);
		this.unPanelIntervention.setVisible(false);
		switch (choix) {
		case 1 : this.unPanelProfil.setVisible(true); break;
		case 2 : this.unPanelClient.setVisible(true); break;
		case 3 : this.unPanelProduit.setVisible(true); break;
		case 4 : this.unPanelTechnicien.setVisible(true); break;
		case 5 : this.unPanelIntervention.setVisible(true); break;
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==this.btProfil) {
			this.afficherPanel(1);
		} else if (e.getSource()==this.btClient) {
			this.afficherPanel(2);
		} else if (e.getSource()==this.btProduit) {
			this.afficherPanel(3);
		} else if (e.getSource()==this.btTechnicien) {
			this.afficherPanel(4);
		} else if (e.getSource()==this.btIntervention) {
			this.afficherPanel(5);
		} else if (e.getSource()==this.btQuitter) {
			OrangeEvent.rendreVisibleLaVueGenerale(false, null);
			OrangeEvent.rendreVisibleVueConnection(true);
		} 
	}
}
