package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

import controleur.Client;
import controleur.Controleur;
import controleur.Tableau;
import controleur.Technicien;
import controleur.User;

public class PanelClient extends PanelPrincipal implements ActionListener {
	private JPanel panelForm= new JPanel();
	private JTextField txtNom = new JTextField();
	private JTextField txtPreNom = new JTextField();
	private JTextField txtEmail = new JTextField();
	private JTextField txtAddresse = new JTextField();
	private JButton btEnregistrer = new JButton("Enregistrer");
	private JButton btAnnuler = new JButton("Annuler");
	private JTable tableClients;
	private JScrollPane uneScroll;
	private Tableau unTableau;
	private JPanel panelFiltre = new JPanel();
	private JButton btFiltrer = new JButton("Filtrer");
	private JTextField txtFiltre = new JTextField();
	private JLabel txtNbClient= new JLabel();
	public String role;
	private Client currentClient;
	private User unUser;
	public PanelClient (User unUser) {
		
		super ("Gestion des clients");
		this.role = unUser.getRole();
		this.unUser = unUser; 
		currentClient = Controleur.selectCompteClient(unUser);
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setBounds(40, 100, 350, 300);
		this.panelForm.setLayout(new GridLayout(5, 2));
		if (!this.role.equals("user")) {
			this.panelForm.add(new JLabel("Nom user:"));
			this.panelForm.add(this.txtNom);
			this.panelForm.add(new JLabel("Prénom user:"));
			this.panelForm.add(this.txtPreNom);
			this.panelForm.add(new JLabel("Addresse user:"));
			this.panelForm.add(this.txtAddresse);
			this.panelForm.add(new JLabel("Email user:"));
			this.panelForm.add(this.txtEmail);
			this.panelForm.add(this.btEnregistrer);
			if (this.role.equals("client")) {
				btEnregistrer.setText("Modifier");
				currentClient = Controleur.selectCompteClient(unUser);
		        if (currentClient != null) {
		            this.txtNom.setText(currentClient.getNom());
		            this.txtPreNom.setText(currentClient.getPrenom());
		            this.txtAddresse.setText(currentClient.getAdresse());
		            this.txtEmail.setText(currentClient.getEmail());
		        } else {
		            System.out.println("No client found.");
		        }
			}
			this.panelForm.add(this.btAnnuler);
			this.add(this.panelForm);
			if (!this.role.equals("client")) {
				//Placement du filtre
				this.panelFiltre.setBackground(Color.gray);
				this.panelFiltre.setBounds(420, 110, 360, 40);
				this.panelFiltre.setLayout(new GridLayout(1, 3));
				this.panelFiltre.add(new JLabel("Filtrer par:"));
				this.panelFiltre.add(this.txtFiltre);
				this.panelFiltre.add(this.btFiltrer);
				this.add(this.panelFiltre);
				this.btFiltrer.addActionListener(this);
			}
			String entetes[]= {"Id Client", "Nom", "Prénom", "Addresse", "Email"};
			this.unTableau = new Tableau(this.obtenirDonnees("", unUser), entetes);
			this.tableClients= new JTable(this.unTableau);
			this.uneScroll= new JScrollPane(this.tableClients);
			this.uneScroll.setBounds(420, 160, 350, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbClient.setBounds(440, 440, 300, 20);
			this.txtNbClient.setText("Le nombre de client(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbClient);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
		} else if (this.role.equals("user")){
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(20, 100, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Client", "Nom", "Prénom", "Addresse", "Email"};
			this.unTableau = new Tableau(this.obtenirDonnees("", unUser), entetes);
			this.tableClients= new JTable(this.unTableau);
			this.uneScroll= new JScrollPane(this.tableClients);
			this.uneScroll.setBounds(20, 160, 650, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbClient.setBounds(270, 440, 300, 20);
			this.txtNbClient.setText("Le nombre de client(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbClient);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
		}
		if (this.role.equals("admin") || this.role.equals("techni")) {
			//Suppression client
			this.tableClients.addMouseListener(new MouseListener() {
			
			
				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
				
				}
			
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
				
				}
			
				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
				
				}
			
				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
				
				}
			
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					int numLigne, idClient;
					if(e.getClickCount() >=2) {
						numLigne= tableClients.getSelectedRow();
						idClient=Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
						int response = JOptionPane.showConfirmDialog(null,  "Voulez vous supprimer le client?", "Suppression client", JOptionPane.YES_NO_OPTION);
						if (response==0) {
							Controleur.deleteClient(idClient);
							unTableau.setDonnees(obtenirDonnees("", unUser));
							PanelProduit.remplirCBXClients();
							String nomP = "deleteClient";
							String tab[]= {idClient+""};
							Controleur.appelProcedure(nomP, tab);
							//Actualisation du nombre de client
							txtNbClient.setText("Le nombre de client(s) est: "+unTableau.getRowCount());
						}
					} else if (e.getClickCount() == 1) {
						numLigne = tableClients.getSelectedRow();
						txtNom.setText(unTableau.getValueAt(numLigne, 1).toString());
						txtPreNom.setText(unTableau.getValueAt(numLigne, 2).toString());
						txtAddresse.setText(unTableau.getValueAt(numLigne, 3).toString());
						txtEmail.setText(unTableau.getValueAt(numLigne, 4).toString());
						btEnregistrer.setText("Modifier");
					}
				}
			});
		}
	}
	public Object [][] obtenirDonnees(String filtre, User unUser){
		if (!this.role.equals("client")) {
			ArrayList <Client> lesClients = Controleur.selectAllClients(filtre);
			Object [][] matrice = new Object [lesClients.size()][5];
			int i = 0;
			for (Client unClient : lesClients) {
				matrice [i][0]=unClient.getIdclient();
				matrice [i][1]=unClient.getNom();
				matrice [i][2]=unClient.getPrenom();
				matrice [i][3]=unClient.getAdresse();
				matrice [i][4]=unClient.getEmail();
				i++;
			}
			return matrice;
		} else if (this.role.equals("client")) {
			Client unClient = Controleur.selectCompteClient(unUser);;
			Object [][] matrice = new Object[1][5];
			 if (unClient != null) {
			        matrice[0][0] = unClient.getIdclient();
			        matrice[0][1] = unClient.getNom();
			        matrice[0][2] = unClient.getPrenom();
			        matrice[0][3] = unClient.getAdresse();
			        matrice[0][4] = unClient.getEmail();
			    }
			return matrice;
		}
		return null;
	}
	@Override
	public void actionPerformed(ActionEvent e ) {
		// TODO Auto-generated method stub
		if (this.role.equals("admin")|| this.role.equals("techni")) {
			if(e.getSource() == this.btAnnuler) {
				this.txtNom.setText("");
				this.txtPreNom.setText("");
				this.txtEmail.setText("");
				this.txtAddresse.setText("");
				this.btEnregistrer.setText("Enregistrer");
			} else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
				String nom = this.txtNom.getText();
				String prenom = this.txtPreNom.getText();
				String email = this.txtEmail.getText();
				String addresse = this.txtAddresse.getText();
				Client unClient = new Client(nom, prenom, addresse, email);
				//Controleur.insertClient(unClient);
				//Appel de la procédure:
				String nomP= "insertClient";
				String tab[]= {nom,prenom,addresse,email};
				Controleur.appelProcedure(nomP, tab);
				//Actualisation de l'affichage
				this.unTableau.setDonnees(this.obtenirDonnees("", null));
				this.txtNom.setText("");
				this.txtPreNom.setText("");
				this.txtEmail.setText("");
				this.txtAddresse.setText("");
				JOptionPane.showMessageDialog(this, "Opération réussie");
				//Actualisation dans le panel produit
				PanelProduit.remplirCBXClients();
				//Actualisation du nombre de client
				this.txtNbClient.setText("Le nombre de client(s) est: "+this.unTableau.getRowCount());
			} else if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			}
			else if (e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String nom = this.txtNom.getText();
				String prenom= this.txtPreNom.getText();
				String addresse= this.txtAddresse.getText();
				String email= this.txtEmail.getText();
				int numLigne = this.tableClients.getSelectedRow();
				int idclient= Integer.parseInt(this.unTableau.getValueAt(numLigne,  0).toString());
				Client unClient= new Client (idclient, nom, prenom, addresse, email);
				Controleur.pdateClient(unClient);
				this.unTableau.setDonnees(this.obtenirDonnees("", null));
				this.txtNom.setText("");
				this.txtPreNom.setText("");
				this.txtAddresse.setText("");
				this.txtEmail.setText("");
				this.btEnregistrer.setText("Enregistrer");
				JOptionPane.showMessageDialog(this, "Modification réussie du client");
				PanelProduit.remplirCBXClients();
			}
		}  else if (this.role.equals("client")) {
			if (e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String nom = this.txtNom.getText();
				String prenom= this.txtPreNom.getText();
				String addresse= this.txtAddresse.getText();
				String email= this.txtEmail.getText();
				int idclient=  currentClient.getIdclient();
				Client unClient= new Client (idclient, nom, prenom, addresse, email);
				Controleur.pdateClient(unClient);
				this.unTableau.setDonnees(this.obtenirDonnees("", this.unUser));
				JOptionPane.showMessageDialog(this, "Modification du client réussie");
				PanelProduit.remplirCBXClients();
			}
		} else {
			if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			}
		}
	}
}
