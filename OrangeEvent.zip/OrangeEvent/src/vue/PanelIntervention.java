package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import controleur.Client;
import controleur.Controleur;
import controleur.Intervention;
import controleur.Produit;
import controleur.Tableau;
import controleur.Technicien;
import controleur.User;

public class PanelIntervention extends PanelPrincipal implements ActionListener {
	private JPanel panelForm= new JPanel();
	private JTextField txtDescription = new JTextField();
	private JTextField txtPrixInter = new JTextField();
	private JTextField txtDateInter = new JTextField();
	private JComboBox<String> txtIdProduit = new JComboBox<String>();
	private JComboBox<String> txtIdTechnicien = new JComboBox<String>();
	private Tableau unTableau;
	private JButton btEnregistrer = new JButton("Enregistrer");
	private JButton btAnnuler = new JButton("Annuler");
	private JTable tableProduits;
	private JScrollPane uneScroll;
	private JPanel panelFiltre = new JPanel();
	private JButton btFiltrer = new JButton("Filtrer");
	private JTextField txtFiltre = new JTextField();
	private JLabel txtNbInter= new JLabel();
	public String role;
	private Intervention mesInterventions; 
	private Client currentClient;
	private User unUser;
	public PanelIntervention (User unUser) {
		super ("Gestion des Interventions");
		this.role=unUser.getRole();
		this.unUser = unUser; 
		currentClient = Controleur.selectCompteClient(unUser);
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setBounds(40, 100, 350, 300);
		this.panelForm.setLayout(new GridLayout(6, 2));
		if (this.role.equals("admin") || this.role.equals("techni")) {
			this.panelForm.add(new JLabel("Description intervention:"));
			this.panelForm.add(this.txtDescription);
			this.panelForm.add(new JLabel("Prix de l'intervention:"));
			this.panelForm.add(this.txtPrixInter);
			this.panelForm.add(new JLabel("Date de l'intervention"));
			this.panelForm.add(this.txtDateInter);
			this.panelForm.add(new JLabel("ID du produit concerné:"));
			this.panelForm.add(this.txtIdProduit);
			this.panelForm.add(new JLabel("ID du technicien:"));
			this.panelForm.add(this.txtIdTechnicien);
			this.panelForm.add(this.btEnregistrer);
			this.panelForm.add(this.btAnnuler);
			this.add(this.panelForm);
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(420, 110, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Intervention", "Description", "Prix intervention", "Date intervention", "ID Produit", "ID Technicien"};
			this.unTableau = new Tableau(this.obtenirDonnees("", unUser), entetes);
			this.tableProduits= new JTable(this.unTableau);
			this.uneScroll= new JScrollPane(this.tableProduits);
			this.uneScroll.setBounds(420, 160, 350, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbInter.setBounds(440, 440, 300, 20);
			this.txtNbInter.setText("Le nombre d'intervention(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbInter);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
			this.remplirCBXProduit();
			this.remplirCBXTechnicien();
		} else if (this.role.equals("user") || this.role.equals("client")) {
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(20, 100, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Intervention", "Description", "Prix intervention", "Date intervention", "ID Produit", "ID Technicien"};
			this.unTableau = new Tableau(this.obtenirDonnees("", unUser), entetes);
			this.tableProduits= new JTable(this.unTableau);
			this.uneScroll= new JScrollPane(this.tableProduits);
			this.uneScroll.setBounds(20, 160, 650, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbInter.setBounds(270, 440, 300, 20);
			this.txtNbInter.setText("Le nombre d'intervention(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbInter);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
			this.remplirCBXProduit();
			this.remplirCBXTechnicien();
		}
		this.tableProduits.addMouseListener(new MouseListener() {
			String role= PanelIntervention.this.role;
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				if (this.role.equals("admin")) {
				// TODO Auto-generated method stub
				int numLigne, idIntervention;
				if(e.getClickCount() >=2) {
					numLigne= tableProduits.getSelectedRow();
					idIntervention=Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
					int response = JOptionPane.showConfirmDialog(null,  "Voulez vous supprimer cette intervention?", "Suppression intervention", JOptionPane.YES_NO_OPTION);
					if (response==0) {
						Controleur.deleteIntervention(idIntervention);
						unTableau.setDonnees(obtenirDonnees("", null));
						PanelProduit.remplirCBXClients();
						//Actualisation du nombre d'interventions
						txtNbInter.setText("Le nombre d'intervention(s) est: "+unTableau.getRowCount());
					}
				} else if (e.getClickCount() == 1) {
					numLigne = tableProduits.getSelectedRow();
					txtDescription.setText(unTableau.getValueAt(numLigne, 1).toString());
					txtPrixInter.setText(unTableau.getValueAt(numLigne, 2).toString());
					txtDateInter.setText(unTableau.getValueAt(numLigne, 3).toString());
					txtIdProduit.setSelectedItem(unTableau.getValueAt(numLigne, 4).toString());
					txtIdTechnicien.setSelectedItem(unTableau.getValueAt(numLigne, 5).toString());
					btEnregistrer.setText("Modifier");
				}
			} else if (this.role.equals("techni")){
				int numLigne, idIntervention;
				mesInterventions = Controleur.selectMesInters(unUser);
				numLigne = tableProduits.getSelectedRow();
				idIntervention=Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
				if (mesInterventions!=null) {
					int idInter= mesInterventions.getIdInter();
					if (idInter==idIntervention) {
						if(e.getClickCount() >=2) {
							int response = JOptionPane.showConfirmDialog(null,  "Voulez vous supprimer cette intervention?", "Suppression intervention", JOptionPane.YES_NO_OPTION);
							if (response==0) {
								Controleur.deleteIntervention(idIntervention);
								unTableau.setDonnees(obtenirDonnees("", null));
								PanelProduit.remplirCBXClients();
								//Actualisation du nombre d'interventions
								txtNbInter.setText("Le nombre d'intervention(s) est: "+unTableau.getRowCount());
							}
						} else if (e.getClickCount() == 1) {
							txtDescription.setText(unTableau.getValueAt(numLigne, 1).toString());
							txtPrixInter.setText(unTableau.getValueAt(numLigne, 2).toString());
							txtDateInter.setText(unTableau.getValueAt(numLigne, 3).toString());
							txtIdProduit.setSelectedItem(unTableau.getValueAt(numLigne, 4).toString());
							txtIdTechnicien.setSelectedItem(unTableau.getValueAt(numLigne, 5).toString());
							btEnregistrer.setText("Modifier");
						}
					} else {
						System.out.println("La ligne séléctionné n'est pas une intervention sur laquelle vous avez travaillé. Vous ne pouvez donc pas faire d'action dessus");
					}
			} else {
				System.out.println("Vous n'avez fait aucune intervention");
			}
		}}
			});
		}
	public Object [][] obtenirDonnees(String filtre, User unUser){
		if (!this.role.equals("client")) {
			ArrayList <Intervention> lesInterventions = Controleur.selectAllIntervention(filtre);
			Object [][] matrice = new Object [lesInterventions.size()][6];
			int i = 0;
			for (Intervention unIntervention : lesInterventions) {
				matrice [i][0]=unIntervention.getIdInter();
				matrice [i][1]=unIntervention.getDescrip();
				matrice [i][2]=unIntervention.getPrixInter();
				matrice [i][3]=unIntervention.getDateInter();
				matrice [i][4]=unIntervention.getIdProduit();
				matrice [i][5]=unIntervention.getIdTechnicien();
				i++;
			}
			return matrice;
		} else if (this.role.equals("client")) {
			Intervention lesInterventions = Controleur.selectMesIntervention(unUser);
			Object [][] matrice = new Object[1][6];
			int i = 0;
			if (lesInterventions != null) {
				matrice [i][0]=lesInterventions.getIdInter();
				matrice [i][1]=lesInterventions.getDescrip();
				matrice [i][2]=lesInterventions.getPrixInter();
				matrice [i][3]=lesInterventions.getDateInter();
				matrice [i][4]=lesInterventions.getIdProduit();
				matrice [i][5]=lesInterventions.getIdTechnicien();
				i++;
			}
			return matrice;
		}
		return null;
	}
	public void remplirCBXProduit() {
		this.txtIdProduit.removeAllItems();
		ArrayList<Produit>lesProduits = Controleur.selectAllProduits("");
		for (Produit unProduit : lesProduits) {
			this.txtIdProduit.addItem(unProduit.getIdproduit()+"-"+unProduit.getDesignation());
		}
	}
	public void remplirCBXTechnicien() {
		this.txtIdTechnicien.removeAllItems();
		ArrayList<Technicien>lesTechniciens = Controleur.selectAllTechnicien("");
		for (Technicien unTechnicien : lesTechniciens) {
			this.txtIdTechnicien.addItem(unTechnicien.getIdtechnicien()+"-"+unTechnicien.getNom());
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (this.role.equals("admin") || this.role.equals("techni")) {
			if(e.getSource() == this.btAnnuler) {
				this.txtDescription.setText("");
				this.txtPrixInter.setText("");
				this.txtDateInter.setText("");
				//this.txtCategorie.setText("");
				this.btEnregistrer.setText("Enregistrer");
			} else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
				String description = this.txtDescription.getText();
				float prixInter = Float.parseFloat(this.txtPrixInter.getText());
				String dateInter = this.txtDateInter.getText();
				String IdProduit = this.txtIdProduit.getSelectedItem().toString();
				String IdTechnicien = this.txtIdTechnicien.getSelectedItem().toString();
				String tabP[] = IdProduit.split("-");
				String tabT[] = IdTechnicien.split("-");
				int idproduit = Integer.parseInt(tabP[0]);
				int idtechnicien = Integer.parseInt(tabT[0]);
				Intervention unIntervention = new Intervention(description, prixInter, dateInter, idproduit, idtechnicien);
				Controleur.insertIntervention(unIntervention);
				this.unTableau.setDonnees(this.obtenirDonnees("", null));
				this.txtDescription.setText("");
				this.txtPrixInter.setText("");
				this.txtDateInter.setText("");
				JOptionPane.showMessageDialog(this, "Opération réussie");
				txtNbInter.setText("Le nombre de client(s) est: "+unTableau.getRowCount());
			} else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String description = this.txtDescription.getText();
				float prixInter= Float.parseFloat(this.txtPrixInter.getText());
				String dateInter= this.txtDateInter.getText();
				String chaine = txtIdProduit.getSelectedItem().toString();
				String tab[] = chaine.split("-");
				int idproduit = Integer.parseInt(tab[0]);
				String chaine2 = txtIdTechnicien.getSelectedItem().toString();
				String tab2[] = chaine.split("-");
				int idtechnicien = Integer.parseInt(tab[0]);
				int numLigne = this.tableProduits.getSelectedRow();
				int idinter= Integer.parseInt(this.unTableau.getValueAt(numLigne,  0).toString());
				Intervention unIntervention= new Intervention (idinter, description, prixInter, dateInter, idproduit, idtechnicien);
				Controleur.updateInter(unIntervention);
				this.unTableau.setDonnees(this.obtenirDonnees("", null));
				this.txtDescription.setText("");
				this.txtPrixInter.setText("");
				this.txtDateInter.setText("");
				this.btEnregistrer.setText("Enregistrer");
				JOptionPane.showMessageDialog(this, "Modification de l'intervention réussie");
				PanelProduit.remplirCBXClients();
			} else if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			}
		} else {
			if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre, null));
			}
		}
	}
}
