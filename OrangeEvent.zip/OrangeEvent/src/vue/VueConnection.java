package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controleur.Controleur;
import controleur.OrangeEvent;
import controleur.User;

public class VueConnection extends JFrame implements ActionListener, KeyListener{
	private JTextField txtEmail = new JTextField("ripoll@gmail.com");
	private JPasswordField txtMdp = new JPasswordField("987");
	private JButton btAnnuler = new JButton ("Annuler");
	private JButton btSeConnecter = new JButton ("Se connecter");
	private JPanel panelForm = new JPanel();
	public VueConnection() {
		
		this.setTitle("Admin BDO Orange Event");
		this.setBounds(100, 100, 750, 350);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setBackground(Color.gray);
		this.setResizable(false);
		this.setLayout(null);
		//insertion du logo
		ImageIcon uneImage=new ImageIcon("src/image/orange.png");
		JLabel LeLogo = new JLabel(uneImage);
		LeLogo.setBounds(30, 40, 250, 250);
		this.add(LeLogo);
		//construction du PanelForm
		this.panelForm.setBounds(340, 40, 280, 250);
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setLayout(new GridLayout(3, 2));
		this.panelForm.add(new JLabel("Email : "));
		this.panelForm.add(this.txtEmail);
		this.panelForm.add(new JLabel("Mdp : "));
		this.panelForm.add(this.txtMdp);
		this.panelForm.add(this.btAnnuler);
		this.panelForm.add(this.btSeConnecter);
		this.add(this.panelForm);
		this.btAnnuler.addActionListener(this);
		this.btSeConnecter.addActionListener(this);
		this.txtEmail.addKeyListener(this);
		this.txtMdp.addKeyListener(this);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == this.btAnnuler) {
			this.txtMdp.setText("");
			this.txtEmail.setText("");
		} else if (e.getSource() == this.btSeConnecter){
		this.traitement();
		}
	}
	public void traitement() {
			String email = this.txtEmail.getText();
			String mdp = new String (this.txtMdp.getPassword());
			User unUser= Controleur.verifConnexion(email, mdp);
			if (unUser!=null) {
				JOptionPane.showMessageDialog(this, "Bienvenue "+ unUser.getNom()+" "+unUser.getPrenom());
				OrangeEvent.rendreVisibleVueConnection(false);
				OrangeEvent.rendreVisibleLaVueGenerale(true, unUser);
			} else {
				System.out.println("Erreur de connexion: Veuillez vérifier vos identifiants");
				this.txtMdp.setText("");
				this.txtEmail.setText("");
			}
		}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			this.traitement();
		}
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
