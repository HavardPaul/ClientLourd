package vue;

import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

public abstract class PanelPrincipal extends JPanel {
	public PanelPrincipal(String message) {
		this.setBounds(100, 100, 900, 600);
		this.setLayout(null);
		this.setBackground(Color.gray);
		JLabel lbTitre = new JLabel(message);
		lbTitre.setBounds(300, 40, 400, 40);
		//création d'une police d'écriture
		Font unePolice = new Font("Arial", Font.BOLD, 20);
		lbTitre.setFont(unePolice);
		this.add(lbTitre);
		this.setVisible(false);
	}
}
