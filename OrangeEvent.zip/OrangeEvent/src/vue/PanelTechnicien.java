package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import controleur.Client;
import controleur.Controleur;
import controleur.Tableau;
import controleur.Technicien;
import controleur.User;

public class PanelTechnicien extends PanelPrincipal implements ActionListener {
	private JPanel panelForm= new JPanel();
	private JTextField txtNom = new JTextField();
	private JTextField txtPreNom = new JTextField();
	private JTextField txtSpec = new JTextField();
	private JTextField txtDateEmb = new JTextField();
	
	private JButton btEnregistrer = new JButton("Enregistrer");
	private JButton btAnnuler = new JButton("Annuler");
	private JTable tableTechniciens;
	private JScrollPane uneScroll;
	private Tableau unTableau;
	private JPanel panelFiltre = new JPanel();
	private JButton btFiltrer = new JButton("Filtrer");
	private JTextField txtFiltre = new JTextField();
	private JLabel txtNbTechnicien= new JLabel();
	public String role;
	private Technicien currentTechnicien; 
	public PanelTechnicien (User unUser) {
		super ("Gestion des techniciens");
		this.role=unUser.getRole();
		this.panelForm.setBackground(Color.gray);
		this.panelForm.setBounds(40, 100, 350, 300);
		this.panelForm.setLayout(new GridLayout(5, 2));
		if (this.role.equals("admin") || this.role.equals("techni")) {
			this.panelForm.add(new JLabel("Nom technicien:"));
			this.panelForm.add(this.txtNom);
			this.panelForm.add(new JLabel("Prénom technicien:"));
			this.panelForm.add(this.txtPreNom);
			this.panelForm.add(new JLabel("Spécialité technicien:"));
			this.panelForm.add(this.txtSpec);
			this.panelForm.add(new JLabel("Date d'embauche:"));
			this.panelForm.add(this.txtDateEmb);
			this.panelForm.add(this.btEnregistrer);
			if (this.role.equals("techni")) {
				btEnregistrer.setText("Modifier");
				currentTechnicien = Controleur.selectCompteTechnicien(unUser);
			    if (currentTechnicien != null) {
			       this.txtNom.setText(currentTechnicien.getNom());
			       this.txtPreNom.setText(currentTechnicien.getPrenom());
			       this.txtSpec.setText(currentTechnicien.getSpecialite());
			       this.txtDateEmb.setText(currentTechnicien.getDateEmbauche());
			    } else {
			        System.out.println("No technicien found.");
			    }
			}
			this.panelForm.add(this.btAnnuler);
			this.add(this.panelForm);
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(420, 110, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Technicien", "Nom", "Prénom", "Spécialité", "Date d'embauche"};
			this.unTableau = new Tableau(this.obtenirDonnees(""), entetes);
			this.tableTechniciens= new JTable(this.unTableau);
			this.uneScroll= new JScrollPane(this.tableTechniciens);
			this.uneScroll.setBounds(420, 160, 350, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbTechnicien.setBounds(440, 440, 300, 20);
			this.txtNbTechnicien.setText("Le nombre de produit(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbTechnicien);
			this.btAnnuler.addActionListener(this);
			this.btEnregistrer.addActionListener(this);
		} else if (this.role.equals("user") || this.role.equals("client")){
			this.panelFiltre.setBackground(Color.gray);
			this.panelFiltre.setBounds(20, 100, 360, 40);
			this.panelFiltre.setLayout(new GridLayout(1, 3));
			this.panelFiltre.add(new JLabel("Filtrer par:"));
			this.panelFiltre.add(this.txtFiltre);
			this.panelFiltre.add(this.btFiltrer);
			this.add(this.panelFiltre);
			this.btFiltrer.addActionListener(this);
			String entetes[]= {"Id Technicien", "Nom", "Prénom", "Spécialité", "Date d'embauche"};
			this.unTableau = new Tableau(this.obtenirDonnees(""), entetes);
			this.tableTechniciens= new JTable(this.unTableau);
			this.uneScroll= new JScrollPane(this.tableTechniciens);
			this.uneScroll.setBounds(20, 160, 650, 250);
			this.uneScroll.setBackground(Color.gray);
			this.add(this.uneScroll);
			this.txtNbTechnicien.setBounds(270, 440, 300, 20);
			this.txtNbTechnicien.setText("Le nombre de produit(s) est: "+this.unTableau.getRowCount());
			this.add(this.txtNbTechnicien);
			
		}
		if (this.role.equals("admin")) {
	//Suppression technicien
			this.tableTechniciens.addMouseListener(new MouseListener() {
				
				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					int numLigne, idTechnicien;
					if(e.getClickCount() >=2) {
						numLigne= tableTechniciens.getSelectedRow();
						idTechnicien=Integer.parseInt(unTableau.getValueAt(numLigne, 0).toString());
						int response = JOptionPane.showConfirmDialog(null,  "Voulez vous supprimer le Technicien?", "Suppression technicien", JOptionPane.YES_NO_OPTION);
						if (response==0) {
							Controleur.deleteTechnicien(idTechnicien);
							unTableau.setDonnees(obtenirDonnees(""));
							PanelProduit.remplirCBXClients();
							//Actualisation du nombre de client
							txtNbTechnicien.setText("Le nombre de client(s) est: "+unTableau.getRowCount());
						}
					} else if (e.getClickCount() == 1) {
						numLigne = tableTechniciens.getSelectedRow();
						txtNom.setText(unTableau.getValueAt(numLigne, 1).toString());
						txtPreNom.setText(unTableau.getValueAt(numLigne, 2).toString());
						txtSpec.setText(unTableau.getValueAt(numLigne, 3).toString());
						txtDateEmb.setText(unTableau.getValueAt(numLigne, 4).toString());
						btEnregistrer.setText("Modifier");
					}
				}
			});
		}}
	public Object [][] obtenirDonnees(String filtre){
		ArrayList <Technicien> lesTechnicien = Controleur.selectAllTechnicien(filtre);
		Object [][] matrice = new Object [lesTechnicien.size()][5];
		int i = 0;
		for (Technicien unTechnicien : lesTechnicien) {
			matrice [i][0]=unTechnicien.getIdtechnicien();
			matrice [i][1]=unTechnicien.getNom();
			matrice [i][2]=unTechnicien.getPrenom();
			matrice [i][3]=unTechnicien.getSpecialite();
			matrice [i][4]=unTechnicien.getDateEmbauche();
			i++;
		}
		return matrice;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (this.role.equals("admin")) {
			if(e.getSource() == this.btAnnuler) {
				this.txtNom.setText("");
				this.txtPreNom.setText("");
				this.txtSpec.setText("");
				this.txtDateEmb.setText("");
				this.btEnregistrer.setText("Enregistrer");
			} else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer")) {
				String nom = this.txtNom.getText();
				String prenom = this.txtPreNom.getText();
				String spec = this.txtSpec.getText();
				String dateEmb = this.txtDateEmb.getText();
				Technicien unTechnicien = new Technicien(nom, prenom, spec, dateEmb);
				Controleur.insertTechnicien(unTechnicien);
				//Actualisation de l'affichage
				this.unTableau.setDonnees(this.obtenirDonnees(""));
				this.txtNom.setText("");
				this.txtPreNom.setText("");
				this.txtSpec.setText("");
				this.txtDateEmb.setText("");
				JOptionPane.showMessageDialog(this, "Opération réussie");
				txtNbTechnicien.setText("Le nombre de client(s) est: "+unTableau.getRowCount());	
			} else if (e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String nom = this.txtNom.getText();
				String prenom= this.txtPreNom.getText();
				String specialite= this.txtSpec.getText();
				String dateEmb= this.txtDateEmb.getText();
				int numLigne = this.tableTechniciens.getSelectedRow();
				int idtechnicien= Integer.parseInt(this.unTableau.getValueAt(numLigne,  0).toString());
				Technicien unTechnicien= new Technicien (idtechnicien, nom, prenom, specialite, dateEmb);
				Controleur.updateTechnicien(unTechnicien);
				this.unTableau.setDonnees(this.obtenirDonnees(""));
				this.txtNom.setText("");
				this.txtPreNom.setText("");
				this.txtSpec.setText("");
				this.txtDateEmb.setText("");
				this.btEnregistrer.setText("Enregistrer");
				JOptionPane.showMessageDialog(this, "Modification du technicien réussie");
				PanelProduit.remplirCBXClients();
			} else if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre));
			}
		} else if (this.role.equals("techni")) {
			if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre));
			} else if (e.getSource()==this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier")) {
				String nom = this.txtNom.getText();
				String prenom= this.txtPreNom.getText();
				String specialite= this.txtSpec.getText();
				String dateEmb= this.txtDateEmb.getText();
				int numLigne = this.tableTechniciens.getSelectedRow();
				int idtechnicien= currentTechnicien.getIdtechnicien();
				Technicien unTechnicien= new Technicien (idtechnicien, nom, prenom, specialite, dateEmb);
				Controleur.updateTechnicien(unTechnicien);
				this.unTableau.setDonnees(this.obtenirDonnees(""));
				JOptionPane.showMessageDialog(this, "Modification du technicien réussie");
				PanelProduit.remplirCBXClients();
			} 
		} else  {
			if (e.getSource() == this.btFiltrer) {
				String filtre = this.txtFiltre.getText();
				//Actuailisation de la matrice des données
				this.unTableau.setDonnees(this.obtenirDonnees(filtre));
			}
		}
	}
}
